const { Router } = require('express');
const router = Router();

const path = requrie('path');
const { unlink } = require('fs-extra');

const Participante = require('../models/Participante');


// obtiene lista de participantes de mongodb
router.get('/', async (req, res) => {
    const participantes = await Participante.find().sort('-_id');
    res.json(participantes);
});

// marca
router.post('/', async (req, res) => {
    const { nombre, moneda, premio } = req.body;
    const imagePath = '/uploads/' + req.file.filename;
    const newParticipante = new Participante({numero, nombre, premio});
    console.log(newParticipante)
    await newParticipante.save();
    res.json({'message': 'Participante Saved'});
});

