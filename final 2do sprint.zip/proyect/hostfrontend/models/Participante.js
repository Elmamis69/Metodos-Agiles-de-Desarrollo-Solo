const { Schema, model } = require('mongoose');

const ParticipanteSchema = new Schema({
    numero: { type: String, required: true },
    nombre: { type: String, required: true },
    premio: { type: String, required: true }
});

module.exports = model('Participante', ParticipanteSchema );