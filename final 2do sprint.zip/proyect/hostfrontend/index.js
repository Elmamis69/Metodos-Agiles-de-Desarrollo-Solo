if (process.env.NODE_ENV !== 'production') {
    require('dotenv').config();
}
// servidor
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const path = require('path');


// configurando servidor... 
const app = express;
require('./database');

// conecta a hosting
app.set('port', process.env.PORT || 4000);

// middleWares necesarios
app.use(morgan('dev'));
app.use(cors());
app.use(express.urlencoded({extended: false}));
app.use(express.json());

// rutas
app.use('/api/participantes', require('./routes/participantes'));

// archivos estaticos
app.use(express.static(path.join(__dirname, 'public')));

// arranca servidor
app.listen(app.get('port'), () => {
    console.log(`Server on port ${app.get('port')}`);
});