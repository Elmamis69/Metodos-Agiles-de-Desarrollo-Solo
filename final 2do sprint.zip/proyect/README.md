# Sorteo #010203




### este script es para ejecutarse en bash/linux, es para conocer como se hizo la aplicacion desde cero.
#!/bin/bash
# este es el guion para la creacion del proyecto
# by: eleAche

mkdir proyect; cd proyect;
npm init -y; touch .env .gitignore .webpack.config.js; # debes tener nodejs de preferencia en su ultima version para ejecutar los siguientes comandos
mkdir host frontend; #host es el que ejecuta el frontend y administra la base de datos para persistencia y en la carpeta frontend/ es donde creas la Interface de Usuario
npm i express express-handlebars cors fs-extra mongoose multer morgan dotenv;
npm i css-loader html-webpack-plugin mini-css-webpack-plugin nodemon style-loader timeago.js webpack webpack-cli webpack-dev-server -D; # el atribudo D hace que los modulos se instalen como dependencias
cd host; mkdir models public routes; cd public; mkdir css js uploads; cd ..; touch database.js index.js public/index.html models/Tarjeta.js routes/tarjeta.js; cd ..; # creamos la estuctura de hostdependencies"
cd frontend; mkdir models services styles; touch app.js index.html UI.js;
