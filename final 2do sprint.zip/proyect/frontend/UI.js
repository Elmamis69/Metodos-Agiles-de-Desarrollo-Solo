import { format } from 'timeago.js';

class UI {
    async renderParticipantes() {
        const participante = await participanteService.getParticipantes();
        const participantesCardContainer = document.getElementById('participantes-cards');
        participantesCardContainer.innerHTML = '';
        participantes.forEach((participantes) => {
            const div = document.createElement('div');
            div.className = 'animated fadeInRigth';
            div.innerHTML = `
            <div class="card m-2">
                <div class="row no-gutters">
                    <div class=col-md-8">
                        <div class"card-block px-2">
                            <h4 class="card-title">${participante.numero}</h4>
                            <p class="card-text">${participante.nombre}</p>
                            <p class="card-text">${participante.premio}</p>
                            <a href="#" class="btn btn-danger delete" _id="${participante._id}">x</a>                     
                        </div>
                    </div>
                </div>
                <div class="card-footer w-100 text-muted">
                   ${format(participante.created_at)}
                </div>
            </div>
            `;
            participantesCardContainer.appendChild(div); 
        
        });
    }

    async addANewParticipante(participante) {
        await participanteService.postParticipante(participante);
        this.renderParticipantes();
        this.clearParticipanteForm();
    }

    clearParticipanteForm() {
        document.getElementById(participante - form).reset();
        document.getElementById('nombre').focus();
    }

    renderMessage(message, colorMessage, secondsToRemove) {
        const div = document.createElement('div');
        div.className = `message ${colorMessage}`;
        // Adding Text to the div
        div.appendChild(document.createTextNode(message));
        // Puting in the documnet
        const container = document.querySelector('.col-md-4');
        const participanteForm = document.querySelector('#participante-form');
        container.insertBefore(div, participanteForm);
        // Removing the div after some secconds
        setTimeout(() => {
            document.querySelector('.message').remove();
        }, secondsToRemove);
    }

        async deleteParticipante(participanteId) {
        await participanteService.deleteParticipante(participanteId);
        this.renderParticipantes();

    }

}

export default UI;