class ParticipanteService {
    
    constructor() {
        this.URI = `/api/participantes`;
    }
    
    // obtener participantes
    async getParticipantes() {
        const response = await fetch(this.URI);
        const participantes = await response.json();
        return participantes;
    }

    async postParticipante(participante) {
        const res = await fetch(this.URI, {
            method: 'POST',
            body: participante
        });
        const data = await res.json();
    }

    async deleteParticipante(participanteId) {
        const res = await fetch(`${this.URI}/${participanteId}`, {
            headers: {
                'Content-Type' : 'application/json',

            },
            method: 'Delete'
        });
        const data = await res.json();
        console.log(data);
    }
}
export default ParticipanteService;
