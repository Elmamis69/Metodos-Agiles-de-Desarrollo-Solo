class Participante {
    constructor(numero, nombre, premio) {
      this.numero = numero;
      this.nombre = nombre;
      this.premio = premio;
    }
  }
  
  export default Participante;
  