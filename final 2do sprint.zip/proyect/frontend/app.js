import "./styles/app.css";

import Participante from './models/Participante.js';
import UI from './UI.js';

document.addEventListener('DOMContentLoaded', () => {
  const ui = new UI();
  ui.renderParticipantes();
});


document.getElementById('participante-form')
  .addEventListener('submit', function(e) {

    const numero = document.getElementById('numero').value;
    const nombre = document.getElementById('nombre').value;
    const premio = document.getElementById('premio').value;
    
    const formData = new FormData();
    formData.append('numero', numero);
    formData.append('nombre', nombre);
    formData.append('premio', premio)

    // for(var pair of formData.entries()) {
    //   console.log(pair[0]+', '+pair[1]);
    // }

    // Instatiating the UI
    const ui = new UI();

    // New Participante Object
    const participante = new Participante(numero, nombre, premio);

    // Validating User Input
    if (numero === '' || nombre === '' || premio === '') {
      ui.renderMessage('Please fill all the fields', 'error', 3000);
    } else {
      // Pass the new participante to the UI
      ui.addANewParticipante(formData);
      ui.renderMessage('New Participante Added Successfully', 'success', 2000);
    }

    e.preventDefault();
  });

document.getElementById('participantes-cards')
  .addEventListener('click', e => {
    const ui = new UI();
    if (e.target.classList.contains('delete')) {
      ui.deleteParticipante(e.target.getAttribute('_id'));
      ui.renderMessage('Participante Deleted Successfully', 'success', 3000);
    }
    e.preventDefault();
  });